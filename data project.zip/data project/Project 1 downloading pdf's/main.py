from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time
from PIL import Image
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from csv_to_json import csv_to_json
import json, os, shutil
from download_file import download_pdf
from webdriver_manager.chrome import ChromeDriverManager





class Open_Browser():

    csvFilePath = r'input_credentials.csv'
    jsonFilePath = r'data.json'
    csv_to_json(csvFilePath, jsonFilePath)

    def launch_browser(self,endupvalue=0,failure_ref_ids=0):
       
        openjsondata=open('data.json')
        data=json.load(openjsondata)[0]

        district_dt=data["select_DISTRICT"]
        ASSEMBLY_dt=data["select_ASSEMBLY"]
        

        global driver
        
        parent_path = "C:\\Users\\navin\\Downloads" # for linux/*nix, download_dir="/usr/Public"
        dir_name="NewDownload111"
        path = os.path.join(parent_path, dir_name)
        try:
            os.mkdir(path)
        except: 
            shutil.rmtree(path)
            os.mkdir(path)
        download_dir=f"C:\\Users\\navin\\Downloads\\{dir_name}" 
        service = Service()
        options = webdriver.ChromeOptions()

        options.add_experimental_option("prefs",{"download.prompt_for_download":False,
                                                "plugins.always_open_pdf_externally":True,
                                                 "download.default_directory": download_dir
                                                #  "browser.helperApps.neverAsk.saveToDisk":"application/pdf",
                                                })
        
        options.add_experimental_option("detach", True)
        # options.headless = True


        driver = webdriver.Chrome(service=service, options=options)
        print("started...")
        driver.implicitly_wait(10)


        # to maximize the browser window
        driver.maximize_window()
        #get method to launch the URL
        driver.get("https://ceoelection.maharashtra.gov.in/searchlist/")
        driver.delete_all_cookies()


        # driver.find_elements(By.ID,"ctl00_Content_DistrictList").click()
        select_DISTRICT=Select(driver.find_element(By.ID,"ctl00_Content_DistrictList"))
        select_DISTRICT.select_by_visible_text(district_dt)
        select_ASSEMBLY=Select(driver.find_element(By.ID,"ctl00_Content_AssemblyList"))
        select_ASSEMBLY.select_by_visible_text(ASSEMBLY_dt)

        window_before=driver.window_handles[0]




        get_len_of_options=Select(driver.find_element(By.ID,"ctl00_Content_PartList"))
        driver.implicitly_wait(10)

        

        download=download_pdf(driver,get_len_of_options,district_dt,ASSEMBLY_dt,window_before,endupvalue,failure_ref_ids)

        print("final result : ",download)

        try:
            if download["No Such Element Found"]:
                endupval=download["EndUp loop reference"]-1
                failure_ref_ids=download["failure_ids"]
                obj.launch_browser(endupval,failure_ref_ids)
        except:
            pass
        
        # driver.quit()


obj=Open_Browser()
obj.launch_browser()

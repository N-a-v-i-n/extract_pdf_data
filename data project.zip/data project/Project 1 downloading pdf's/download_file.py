from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time
from PIL import Image
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import csv_to_json
import json,os
from google_vision_api import detect_properties
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait



def download_pdf(driver,get_len_of_options,district_dt,ASSEMBLY_dt,window_before,endupvalue,failure_ref_ids):

    global current_val
    try:
        driver.implicitly_wait(10)
        failure_ids=[]
        for val in range(endupvalue,len(get_len_of_options.options)-1):
            try:
                get=Select(driver.find_element(By.ID,"ctl00_Content_PartList"))
                current_value=get.select_by_value(str(val+1))
                driver.switch_to.window(window_before)
                captcha_img=driver.find_element(By.XPATH,"//tbody/tr[6]/td[2]/img[1]")

                revealed = driver.find_element(By.XPATH,"//tbody/tr[6]/td[2]/img[1]")
                wait = WebDriverWait(driver, timeout=10)
                wait.until(lambda d : revealed.is_displayed())

                captcha_img.screenshot("captcha_img.png")

                captcha_text=detect_properties("C:/Users/navin/OneDrive/Desktop/New/captcha_img.png")
                get_captcha_entry=driver.find_element(By.ID,"ctl00_Content_txtcaptcha")
                get_captcha_entry.send_keys(captcha_text)
                
                # value=get_captcha_entry.get_attribute("value")
                press_openPDF=driver.find_element(By.ID,"ctl00_Content_OpenButton").click()

                windowss=driver.window_handles

                # driver.switch_to.window(window_before)

            except Exception as err:
                print("Inner exact handles")
                try:
                    split_str=str(err).split("Alert Text")
                    print("error : ",err)
                    temp=str(err).split(":")
                    print("error split : ",temp)
                    print("taking : ",temp[1])
                    if str(temp[1])==" no such element":
                        print("entererd")
                        data ={
                            "No Such Element Found": True,
                            "EndUp loop reference":val+1,
                            "failure_ids" : failure_ids
                        }
                        driver.quit()
                        return data

                        
                except:
                    print(" eeerror : ",err)
                    
                if "Alert Text" in split_str:
                    get_all_win=driver.window_handles
                    print("ALL Windows : ",get_all_win)
                    for x in get_captcha_entry:
                        if x!=window_before:
                            driver.switch_to.window(x)
                            alert=driver.switch_to.alert
                            alert.accept()
                            
                    driver.switch_to.window(window_before)
                
                else:
                    print("Exception skipped...",val)
                    with open("create_failed.txt",'a') as file :
                        file.write(f"{val},")
                    print("Noted Response")
                    continue




            try:    
                # print("Try Block Window ID : ")
                if len(windowss)>1:
                    print(windowss)
                    driver.switch_to.window(windowss[1])
                    try:
                        alert_ref=driver.switch_to.alert
                        driver.implicitly_wait(10)
                        alert_ref.accept()
                        failure_ids.append(val+1)
                        current_val=val+1
                    except:
                        pass
                    driver.close()
                    driver.switch_to.window(window_before)
                else:
                    driver.switch_to.window(window_before)

            except:
                
                # print("Expect Block Window ID : ")
                try:
                    for x in windowss:
                        # time.sleep(1)
                        if x == windowss[0]:
                            continue
                        else:
                            driver.switch_to.window(x)
                            driver.implicitly_wait(10)
                            try:
                                alert_ref=driver.switch_to.alert
                                driver.implicitly_wait(10)
                                alert_ref.accept()
                            except:
                                pass
                        
                            driver.close()
                            print("switching to window : ",x)
                except:
                    pass
                driver.switch_to.window(window_before)
            driver.switch_to.window(window_before)
        if failure_ref_ids:
            for x in failure_ref_ids:
                failure_ids.append(x)

        if failure_ids:
            print("Failure ids : ",failure_ids)
            result = download_again_for_failure_ids(driver,failure_ids,district_dt,ASSEMBLY_dt,window_before)

            
            return result
        else:
            # print("result : ",result)
            data={
                "Downloading " : "Successfully",
            }

            return json.dumps(data)
    except Exception as error:  #spelling error making this code not work as expected
        print("Hey, error occured : ",error)
        try:          
            driver.switch_to.window(window_before)
        except:
            pass



        print("Last stoped value is : ",current_value)



def download_again_for_failure_ids(driver,failure_ids,district_dt,ASSEMBLY_dt,window_before):

    failed_ids=[]
    print("Failure ids are redownloading .....")
    print("failure id are : ",failure_ids)
   
    for val in failure_ids:
        try:
            # print()
            # print()
            print("Redownloading id : ",val)
            # driver.switch_to.window(window_before)
            get=Select(driver.find_element(By.ID,"ctl00_Content_PartList"))
            current_value=get.select_by_value(str(val))
            
            captcha_img=driver.find_element(By.XPATH,'//*[@id="aspnetForm"]/div[3]/article/table/tbody/tr[6]/td[2]/img')
        
            captcha_img.screenshot("captcha_img.png")
            
            captcha_text=detect_properties("C:/Users/navin/OneDrive/Desktop/New/captcha_img.png")

            get_captcha_entry=driver.find_element(By.ID,"ctl00_Content_txtcaptcha")
            get_captcha_entry.send_keys(captcha_text)
            # value=get_captcha_entry.get_attribute("value")
            press_openPDF=driver.find_element(By.ID,"ctl00_Content_OpenButton").click()
            # print("Captcha Value : ",value)
            windowss=driver.window_handles
        
            driver.switch_to.window(window_before)
            try:    
                # print("Try Block Window ID : ")
                if len(windowss)>1:
                    print(windowss)
                    driver.switch_to.window(windowss[1])
                    try:
                        alert_ref=driver.switch_to.alert
                        alert_ref.accept()
                        failed_ids.append(val)
                    except:
                        pass
                    driver.close()
                    driver.switch_to.window(window_before)
                else:
                    pass
            except:
                # print("Expect Block Window ID : ")
                try:
                    for x in windowss:
                        # time.sleep(1)
                        if x == windowss[0]:
                            continue
                        else:
                            driver.switch_to.window(x)
                            try:
                                alert_ref=driver.switch_to.alert
                                alert_ref.accept()
                            except:
                                pass
                        
                            driver.close()
                            print("switching to window : ",x)
                except:
                    pass
                driver.switch_to.window(window_before)
                pass
        except Exception as err:
            print("Inner exact handles")
            try:
                split_str=str(err).split("Alert Text")
                temp=str(err).split(":")
                print("error split : ",temp)
                print("taking : ",temp[1])
                if str(temp[1])==" no such element":
                    print("entererd")
                    data ={
                        "No Such Element Found": True,
                        "EndUp loop reference":val+1,
                        "failure_ids" : failure_ids
                    }
                    driver.quit()
                    return data
            except:
                pass
            if "Alert Text" in split_str:
                get_all_win=driver.window_handles
                print("ALL Windows : ",get_all_win)
                for x in get_captcha_entry:
                    if x!=window_before:
                        driver.switch_to.window(x)
                        alert=driver.switch_to.alert
                        alert.accept()
                        
                driver.switch_to.window(window_before)
            else:
                print("Exception skipped...")
                with open("create_failed.txt",'a') as file :
                    file.write(f"{val},")
                print("Noted Response")
                continue


    
    if failed_ids:
        data={
            "result":False,
            "Unsuccessfull ids": failed_ids
        }
        try:
            for x in windowss:
                if x == windowss[0]:
                    continue
                else:
                    driver.switch_to.window(x)
                    try:
                        alert_ref=driver.switch_to.alert
                        alert_ref.accept()
                    except:
                        pass
                
                    driver.close()
                    print("switching to window : ",x)
        except:
            pass
        driver.switch_to.window(window_before)
                    
        download_again_for_failure_ids(driver,failed_ids,district_dt,ASSEMBLY_dt,window_before)
        # return json.dumps(data)
    else :
        data={
            "result": True,
            
        }
        return json.dumps(data)
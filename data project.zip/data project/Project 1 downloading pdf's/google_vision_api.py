import os, time,json,requests
from google.cloud import vision
from selenium.webdriver.common.by import By
from google.cloud.vision import ImageAnnotatorClient

os.environ['GOOGLE_APPLICATION_CREDENTIALS']='thermal-outlet-397608-76ee15e38de2.json'


def detect_properties(path):
    """Detects image properties in the file."""
    from google.cloud import vision

    client = vision.ImageAnnotatorClient()

    with open(path, "rb") as image_file:
        content = image_file.read()

    image = vision.Image(content=content)

    text_data=[]
    respnse_text= client.text_detection(image=image)
    for r in respnse_text.text_annotations:
        d={
            'text':r.description
        }
        text_data.append(d)
        print(d)

    if respnse_text.error.message:
        raise Exception(
            "{}\nFor more info on error messages, check: "
            "https://cloud.google.com/apis/design/errors".format(respnse_text.error.message)
        )
    try:
        captcha=text_data[0]["text"]
    except:
        captcha="NONE"
    return captcha



















































# import os, time
# from google.cloud import vision
# from selenium.webdriver.common.by import By

# os.environ['GOOGLE_APPLICATION_CREDENTIALS']='maximal-codex-389709-da1acbe39a63.json'

# # from google.cloud.vision import types

# def pass_captcha():

#     client = vision.ImageAnnotatorClient()
#     # [END vision_python_migration_client]

#     # The URI of the image file to annotate
#     file_uri = "C:/Users/navin/OneDrive/Desktop/New folder/captcha_img.png"

#     image = vision.Image()
#     image.source.image_uri = file_uri

#     # Performs label detection on the image file
#     response = client.label_detection(image=image)
#     print(response)


#     # text detection

#     text_data=[]
#     respnse_text= client.text_detection(image=image)
#     for r in respnse_text.text_annotations:
#         d={
#             'text':r.description
#         }
#         text_data.append(d)
#         print(d)
#     return "NONE"
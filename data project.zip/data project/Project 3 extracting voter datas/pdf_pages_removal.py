from pypdf import PdfMerger
import glob
pdfs = [x for x in glob.glob("*")]
# print(pdfs)
from PyPDF2 import PdfWriter, PdfReader

# merger = PdfMerger()
count=0
for pdf in pdfs:
    
    if pdf != "main.py":
        pd=PdfReader(pdf)
        len_of_pdf=len(pd.pages)

        pages_to_keep = [x for x in range(3,len_of_pdf-1)] 
        
        infile = PdfReader(pdf, 'rb')
        output = PdfWriter()

        for i in pages_to_keep:
                p = infile.pages[i] 
                output.add_page(p)

        with open(f'newfile{count}.pdf', 'wb') as f:
                output.write(f)
        count=count+1
#         # merger.append(pdf)

        # merger.append(pdf, pages=(2, len_of_pdf-1))

# merger.write("result.pdf")
# merger.close()
from pdf2image import convert_from_path, convert_from_bytes
import easyocr
from googletrans import Translator
import csv
import cv2


def get_all_cropped_data(pdf_file):

    # List no:
    reader = easyocr.Reader(['hi'])
    croppedlistImage = pdf_file[110:200, 1250:745*2]
    List_no=(reader.readtext(croppedlistImage,detail=0))

    croppeddetails_inspection_Image = pdf_file[380:670, 80:850]
    Details_of_Inspections=(reader.readtext(croppeddetails_inspection_Image,detail=0))
 
    crop_Identifications_of_list=pdf_file[380:710, 850:760*2]
    Identifications_of_list=(reader.readtext(crop_Identifications_of_list,detail=0))

    crop_polling_area_details=pdf_file[770:650*2, 80:660]
    polling_area_details=(reader.readtext(crop_polling_area_details,detail=0))

    crop_Polling_station_details=pdf_file[1410:1630, 80:660]
    Polling_station_details=(reader.readtext(crop_Polling_station_details,detail=0))

    # crop_type_of_polling_station=img[1405:870, 1630:760*2]
    # type_of_polling_station=(reader.readtext(crop_type_of_polling_station,detail=0))

    crop_Number_of_voters_start=pdf_file[1800:1850, 70:300]
    Number_of_voters_start=(reader.readtext(crop_Number_of_voters_start,detail=0))

    crop_Number_of_voters_end=pdf_file[1800:1850, 290:280*2]
    Number_of_voters_end=(reader.readtext(crop_Number_of_voters_end,detail=0))

    crop_Number_of_voters_male=pdf_file[1800:1850, 600:800]
    Number_of_voters_male=(reader.readtext(crop_Number_of_voters_male,detail=0))

    crop_Number_of_voters_female=pdf_file[1800:1850, 850:1000]
    Number_of_voters_female=(reader.readtext(crop_Number_of_voters_female,detail=0))

    crop_Number_of_voters_third_party=pdf_file[1800:1850, 1100:1300]
    Number_of_voters_third_party=(reader.readtext(crop_Number_of_voters_third_party,detail=0))

    crop_Number_of_voters_total=pdf_file[1800:1850, 1300:1500]
    Number_of_voters_total=(reader.readtext(crop_Number_of_voters_total,detail=0))
    print(Number_of_voters_male)


    return List_no,Details_of_Inspections,Identifications_of_list,polling_area_details,Polling_station_details,Number_of_voters_start,Number_of_voters_end,Number_of_voters_male,Number_of_voters_female,Number_of_voters_third_party,Number_of_voters_total


def crop_images(pdf_file,x):
    # nazri naksha
    crop_naksha=pdf_file[200:670,170:730]
    cv2.imwrite(f"data3/crop_naksha{x}.jpg",crop_naksha)

    # google map
    crop_google_map=pdf_file[190:670,800:1400]
    cv2.imwrite(f"data3/crop_google_map{x}.jpg",crop_google_map)

    # polling station front building
    crop_pollingstation_buliding=pdf_file[690:1220,170:730]
    cv2.imwrite(f"data3/crop_pollingstation_buliding{x}.jpg",crop_pollingstation_buliding)


    # polling station front view
    crop_pollingstation_view=pdf_file[690:1220,800:1400]
    cv2.imwrite(f"data3/crop_pollingstation_view{x}.jpg",crop_pollingstation_view)

    # cad view
    crop_cad_view=pdf_file[1240:1800,170:730]
    cv2.imwrite(f"data3/crop_cad_view{x}.jpg",crop_cad_view)


    # key map
    crop_key_map=pdf_file[1240:1800,800:1400]
    cv2.imwrite(f"data3/crop_key_map{x}.jpg",crop_key_map)

    return crop_naksha,crop_google_map,crop_pollingstation_buliding,crop_pollingstation_view,crop_cad_view,crop_key_map
# 

#type_of_polling_station, 
fields=["List No","State District","Assembly","Details of Inspections","Identifications of list","polling area details","Polling station details","Number of voters start","Number of voters end","Number_of_voters_male","Number_of_voters_female","Number_of_voters_third_party","Number_of_voters_total","Nazri Naksha","Google Map View","Polling station Building Front View","Polling Station Front View","CAD View","Key MAP View"]
# "Nazri Naksha","Google Map View","Polling station Building Front View","Polling Station Front View","CAD View","Key MAP View"
csv_file=open("data_file_with_image_path.csv","a",encoding='utf-8')
write_fields=csv.writer(csv_file)
write_fields.writerow(fields)



for x in range(275):
    print("Loop : ",x)
    data_pdf = cv2.imread(f"data1/new{x}.jpg")
    data_image=cv2.imread(f"data2/new_img_data{x}.jpg")

    List_no,Details_of_Inspections,Identifications_of_list,polling_area_details,Polling_station_details,Number_of_voters_start,Number_of_voters_end,Number_of_voters_male,Number_of_voters_female,Number_of_voters_third_party,Number_of_voters_total=get_all_cropped_data(data_pdf)

    crop_naksha,crop_google_map,crop_pollingstation_buliding,crop_pollingstation_view,crop_cad_view,crop_key_map=crop_images(data_image,x)

    crop_naksha=f"file:///C:/data3/crop_naksha{x}.jpg"
    crop_google_map=f"file:///C:/data3/crop_google_map{x}.jpg"
    crop_pollingstation_buliding=f"file:///C:/data3/crop_pollingstation_buliding{x}.jpg"
    crop_pollingstation_view=f"file:///C:/data3/crop_pollingstation_view{x}.jpg"
    crop_cad_view=f"file:///C:/data3/crop_cad_view{x}.jpg"
    crop_key_map=f"file:///C:/data3/crop_key_map{x}.jpg"

    
    try:
        if List_no[1]:
            list_number=List_no[1]
    except:
        list_number="blank"
    write_fields.writerow([list_number,"Sindhudurg","269 - Kudal",Details_of_Inspections,Identifications_of_list,polling_area_details,Polling_station_details,Number_of_voters_start,Number_of_voters_end,Number_of_voters_male,Number_of_voters_female,Number_of_voters_third_party,Number_of_voters_total,crop_naksha,crop_google_map,crop_pollingstation_buliding,crop_pollingstation_view,crop_cad_view,crop_key_map])
 






